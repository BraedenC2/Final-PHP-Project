<?php
// Include the PDO connection file
include("pdo_connect.php");

// Query to retrieve courses
$sql = "SELECT course_id, title, description, credits, gened 
        FROM courses 
        ORDER BY title";

// Execute the query
$results = fetchResults($db, $sql);

// Display the course catalog
echo "<h2>Course Catalog</h2>";
echo "<table class='table table-striped'>";
echo "<tr><th>Course</th><th>Title</th><th>Description</th><th>Credits</th><th>Gen Ed</th></tr>";

foreach ($results as $course) {
    echo "<tr>";
    echo "<td>". $course['course_id']. "</td>";
    echo "<td>". $course['title']. "</td>";
    echo "<td>". $course['description']. "</td>";
    echo "<td>". $course['credits']. "</td>";
    echo "<td>". $course['gened']. "</td>";
    echo "</tr>";
}

echo "</table>";

// Include the footer
include('footer.html');

// Function to fetch results (same as in index.php)
function fetchResults($db, $sql, $parametervalues = null)
{
    //prepare statement class
    $stm = $db->prepare($sql);

    // Execute the statement with named parameters
    $stm->execute($parametervalues);

    // Fetch the result set
    $list = $stm->fetchAll(PDO::FETCH_ASSOC);

    // Return the result set
    return $list;
}