<?php
session_start();

/* This script performs several tasks
1. Add a new record
2. Update existing record
3. Delete a record

*/

include("pdo_connect.php");
include('header.html');
include("navigation.php");

// Check if the adminID is already stored using a session variable then display a message

if (empty($_SESSION['memberID']) && empty($_REQUEST['username']))
{
   // Invalid user
   displayloginform();
   exit();
} 

$parameterValues = null;
$mode = "";
if (isset($_REQUEST["mode"]))
{
    $mode = $_REQUEST["mode"];
}

switch ($mode)

{
    case "signout":
        // Destroy session variables and display the login form
        session_unset();
        setcookie(session_name(), '', time()-1000, '/');
        $_SESSION = array();
 // Need to reload the page to hide navigation links
        header('Location: index.php');
        break;

    case 'login':
        // Validate user
        if (isset($_REQUEST['username']))
        {
            // Validate user
            $username = (!empty($_REQUEST['username']))? $_REQUEST['username'] : "";
            $password = (!empty($_REQUEST['password']))? $_REQUEST['password'] : "";
            if ($username == "" || $password == "")
            {
                // Invalid data
                echo "<p>Invalid data</p>";
                displayloginform();
            } else {
                // Validate the username and password
                $sql = "SELECT memberID, username, firstName, lastName 
                FROM `members` 
                WHERE TRIM(username) = TRIM(:username) and TRIM(password) = TRIM(:password)";
        
                // Bind values to named parameters
                $parameterValues = [ ":username" => trim($username),
                    ":password" => trim($password)
                ];
                // Execute SQL statement
                $results = fetchResults($db, $sql, $parameterValues);
        
                // First element of the $results array should include matching record           
                if (!empty($results[0]['memberID']))
                {
                    // Valid user - Define session variables
                    $_SESSION['memberID'] = $results[0]['memberID'];
                    $_SESSION['name'] = $results[0]['firstName']. ' '. $results[0]['lastName'];
        
         // Need to reload the page to display navigation links
                    header('Location: index.php');
        
                } else {
                    // Invalid user
                    echo "Invalid user";
                    displayloginform();
                    exit();
                }
            }
        }
        break;

    case 'catalog':
        // Display course catalog
        include('course_catalog.php');
        break;

    default:
        displayHomePage();
        break;
}

include('footer.html');

function fetchResults($db, $sql, $parametervalues = null)
{
    //prepare statement class
    $stm = $db->prepare($sql);

    // Execute the statement with named parameters
    $stm->execute($parametervalues);

    // Fetch the result set
    $list = $stm->fetchAll(PDO::FETCH_ASSOC);

    // Return the result set
    return $list;
}

function displayHomePage()
{
 echo "<h2>Semester Planner</h2>";
 echo "<p>Welcome to your semester planner!!! Be smart!</p>";
}

function displayloginform(){
  ?>
    <form action="index.php?mode=login" method="post" class="form-signin">
 <h3>Semester Planner</h3>
        <p>username: <input type="text" name="username" class = "form-control" /></p>
        <p>Password: <input type="password" name="password" class = "form-control" /></p>
    <p><button type="submit"  class="btn btn-primary ">Sign in</button></p>
    </form>
    <?php
    }
?>