<?php
// Query to retrieve courses
$sql = "SELECT subject, number, title, description, credits, gened 
        FROM courses 
        ORDER BY number";

// Execute the query
$results = fetchResults($db, $sql);

// Display the course catalog
echo "<h2>Course Catalog</h2>";
echo "<table class='table table-striped'>";
echo "<tr><th>Subject</th><th>Number</th><th>Title</th><th>Description</th><th>Credits</th><th>Gen Ed</th></tr>";

foreach ($results as $course) {
    echo "<tr>";
    echo "<td>". $course['subject']. "</td>";
    echo "<td>". $course['number']. "</td>";
    echo "<td>". $course['title']. "</td>";
    echo "<td>". $course['description']. "</td>";
    echo "<td>". $course['credits']. "</td>";
    echo "<td>". $course['gened']. "</td>";
    echo "</tr>";
}

echo "</table>";
?>